# Stream On Demand PureITA

![alt tag](https://raw.githubusercontent.com/orione7/plugin.video.streamondemand-pureita/master/icon.png)


Son of pelisalacarta:

italian STREAM ON DEMAND PUREITA


Fork of Pelisalacarta-ui, fully translated and customized with only italian channels.

Made for touch devices and thinked to have the same User Interface on all your Kodi, Openelec, LibreElec installations and skins.

Easily installable via Add-on manager on Kodi, Openelec, LibreElec, this version have self-updates enabled by default.

All the erotic channels were removed, Kodi, Openelec, LibreElec repositories are full of add-on made to view this kind of contents.

