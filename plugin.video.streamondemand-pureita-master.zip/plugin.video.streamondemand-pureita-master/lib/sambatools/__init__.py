# -*- coding: utf-8 -*-
#------------------------------------------------------------
# pelisalacarta
# http://www.mimediacenter.info/foro/viewforum.php?f=36
#------------------------------------------------------------
import os
import sys
sys.path.append(os.path.dirname(__file__))